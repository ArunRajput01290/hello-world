from django.apps import AppConfig


class DpQuestionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dp_question'
